<?php 
/*

	Plugin Name: removelogo
	Description: Remove WP Logo from admin bar
	Author: Kevin Pichette
	Version: 1.0
	Author URI: http://kevinpichette.com

*/

add_action('admin_bar_menu', 'remove_wp_logo', 999);

function remove_wp_logo($wp_admin_bar)
{
	$wp_admin_bar->remove_node('wp-logo');
}

?>